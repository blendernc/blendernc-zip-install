## Line Integral Convolution (LIC)

LIC in BlenderNC is currently implemented by using the `cython` implementation
by **AMArchibald**.

More information can be found at:
<https://scipy-cookbook.readthedocs.io/items/LineIntegralConvolution.html>
